import { isNumber } from "../../../../dms-core/app/utils/type-check";

/**
 * Width of one character of the axis font (11px, monospace) in pixels, with a
 * little room for a proportional fallback font.
 */
const AXIS_CHAR_WIDTH = 7;
/** Blank space kept between two neighbouring labels. */
const LABEL_GAP = 8;

/** What Apex hands an x-axis label formatter (`xaxis.labels.formatter`). */
interface ApexLabelFormatterOpts {
  /** The label's column; only set while Apex draws the axis. */
  i?: number;
  w?: { globals?: { gridWidth?: number; labels?: unknown[] } };
}

type ApexLabelFormatter = (
  value: string,
  timestamp?: number,
  opts?: ApexLabelFormatterOpts,
) => string;

/**
 * How many columns each drawn label stands for: 1 while every label fits its
 * column, more once the longest one is wider than a column.
 */
export function categoryLabelStep(
  gridWidth: number,
  labelCount: number,
  longestLabel: number,
): number {
  if (labelCount <= 1 || gridWidth <= 0) return 1;
  const columnWidth = gridWidth / labelCount;
  const labelWidth = longestLabel * AXIS_CHAR_WIDTH + LABEL_GAP;
  return Math.max(1, Math.ceil(labelWidth / columnWidth));
}

/**
 * A category x-axis gives every point a label and ApexCharts does not thin
 * them (`hideOverlappingLabels` only acts on numeric and datetime axes), so a
 * long series or a narrow plot runs them into each other ("Aug 4, 2026Aug 8,
 * 2026"). This formatter keeps one label every few columns, from the plot's
 * width, and leaves the tooltip's (no column index) whole.
 */
export function thinnedCategoryFormatter(
  format: ApexLabelFormatter | undefined,
): ApexLabelFormatter {
  const write = (
    value: string,
    timestamp?: number,
    opts?: ApexLabelFormatterOpts,
  ): string => (format ? format(value, timestamp, opts) : String(value ?? ""));
  return (value, timestamp, opts) => {
    const label = write(value, timestamp, opts);
    const index = opts?.i;
    const globals = opts?.w?.globals;
    if (!isNumber(index) || !globals) return label;
    const labels = globals.labels ?? [];
    const longest = labels.reduce<number>(
      (max, entry) => Math.max(max, write(String(entry ?? "")).length),
      0,
    );
    const step = categoryLabelStep(
      globals.gridWidth ?? 0,
      labels.length,
      longest,
    );
    return index % step === 0 ? label : "";
  };
}

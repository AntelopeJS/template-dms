import type { Component } from "vue";
import type { Table } from "@tanstack/vue-table";
import type { TableViewColumn } from "./column";
import type { CustomRowAction } from "../../../types/row-action";
import type { TableViewPaginationMode } from "./config";
import type { Data } from "../../../build/components/table/Table.vue";

/** The built-in grid display id. */
export const TABLE_DISPLAY_ID = "table";
/** The built-in kanban display id. */
export const KANBAN_DISPLAY_ID = "kanban";
/** The built-in cards display id. */
export const CARDS_DISPLAY_ID = "cards";
/** The built-in grouped display id. */
export const GROUPED_DISPLAY_ID = "grouped";

/**
 * Display ids the DMS keeps for its built-in displays: a module registers its
 * own under `<module>:<id>`.
 */
export const RESERVED_TABLE_VIEW_DISPLAY_IDS = [
  TABLE_DISPLAY_ID,
  KANBAN_DISPLAY_ID,
  CARDS_DISPLAY_ID,
  GROUPED_DISPLAY_ID,
] as const;

/**
 * A row "actor" currently editing an item (realtime presence). Keyed by row id
 * in {@link TableViewPresenceMap}. Part of the public display contract so a
 * custom display can surface "X is editing this" affordances.
 */
export interface TableViewPresenceActor {
  id: string;
  displayName?: string;
  avatarUrl?: string;
  sessionId: string;
  since?: number;
}

export type TableViewPresenceMap = Record<string, TableViewPresenceActor[]>;

/**
 * Selection API exposed to a display. Keys live in the same id space as
 * `rowIdKey` (TanStack `getRowId` reads the same key), so a display and the
 * built-in grid share one selection state.
 */
export interface TableViewDisplaySelection {
  ids: string[];
  isSelected: (id: string) => boolean;
  toggle: (id: string, value?: boolean) => void;
  toggleAll: (value?: boolean) => void;
  clear: () => void;
}

/**
 * Pagination API exposed to a display. For a shared-data display (the common
 * case) these mutate the table view's global pagination, so changing the page
 * re-runs the shared list query.
 */
export interface TableViewDisplayPagination {
  pageIndex: number;
  pageSize: number;
  total: number;
  setPage: (index: number) => void;
  setPageSize: (size: number) => void;
  /**
   * How the rows beyond the first page are reached: with `loadMore` and
   * `infinite`, `items` holds every row loaded so far and `loadMore()`
   * appends the next page while `hasMore`.
   */
  mode: TableViewPaginationMode;
  hasMore: boolean;
  loadMore: () => void;
}

/**
 * Resolved row-action capabilities + handlers, identical to what the grid uses.
 * The `canXRow` predicates evaluate per-row rules (e.g. conditional edit/delete)
 * so a display can gate affordances on individual items.
 */
export interface TableViewDisplayActions<T> {
  canAdd: boolean;
  canEdit: boolean;
  canDelete: boolean;
  canDetails: boolean;
  canEditRow: (item: T) => boolean;
  canDeleteRow: (item: T) => boolean;
  add: () => void;
  edit: (item: T) => void;
  /**
   * Deletes the rows once confirmed. A display drawing rows the grid does not
   * list (a kanban card) hands them in `rows`, so a dialog can name them.
   */
  delete: (ids: string[], rows?: T[]) => void;
  duplicate: (id: string) => void;
  details: (item: T) => void;
  /** What a click on the row does in the grid: its default action. */
  open: (item: T) => void;
  /** Runs a custom row action on the row, as its grid menu entry does. */
  custom: (action: CustomRowAction, item?: T) => void;
  /**
   * The table's custom row actions the row offers: those whose `rule` accepts
   * it, in their declared order. A card drawing its own menu lists these and
   * runs one with `custom`; an action's `id` finds a given one.
   */
  customFor: (item: T) => CustomRowAction[];
}

/**
 * Rows ordered by hand (backend `reorder`), as a display moves them. Set on
 * the displays that draw the rows in their order (the grid and `cards`), for
 * a caller who may edit them.
 */
export interface TableViewDisplayReorder {
  /** Off while a search, a filter or a tab narrows the rows. */
  enabled: boolean;
  /** Moves the row at `from` to `to`, both indexes into `items`. */
  move: (from: number, to: number) => void;
}

/**
 * The attributes and listeners of a move handle: `v-bind` them on a
 * `<button>`. Dragged, it moves its row onto the card it is dropped on; with
 * it focused, the arrow keys move the row one place back (up, left) or
 * forward (down, right).
 */
export interface TableViewReorderHandle {
  type: "button";
  draggable: boolean;
  disabled: boolean;
  "aria-label": string;
  /** Says how to move the row, or, while moving is off, how to turn it on. */
  title: string;
  onClick: (event: MouseEvent) => void;
  onDragstart: (event: DragEvent) => void;
  onDragend: () => void;
  onKeydown: (event: KeyboardEvent) => void;
}

/** A card's move handle, on a hand-ordered `cards` display. */
export interface TableViewCardReorder {
  /** Off while a search, a filter or a tab narrows the rows. */
  enabled: boolean;
  /** The card is the one being dragged. */
  dragging: boolean;
  /** Bind on the element the card is moved by. */
  handle: TableViewReorderHandle;
}

/**
 * The card the `kanban` and `cards` displays draw (backend `card` option):
 * the columns it shows, or a component drawing it whole.
 */
export interface TableViewCardConfig {
  fields?: string[];
  component?: ComponentInfo;
  /** `cards` only: the narrowest a card gets, a CSS length (`230px` left out). */
  minWidth?: string;
  /** `cards` only: the height of a placeholder card, a CSS length. */
  skeletonHeight?: string;
}

/**
 * The props a custom card component receives, the same in the `kanban` and
 * `cards` displays.
 */
export interface TableViewCardProps<T = Data> {
  /** The row the card stands for. */
  row: T;
  /** Its id (its `rowIdKey` value). */
  rowId: string;
  /** Column metadata of the table view (types, labels). */
  columns: TableViewColumn[];
  /** Field naming the row, if configured. */
  labelKey?: string;
  /** The table's row actions and their per-row predicates. */
  actions: TableViewDisplayActions<T>;
  /** The row is selected. */
  selected: boolean;
  /** Selects the row, or unselects it (`false`); toggles without a value. */
  select: (value?: boolean) => void;
  /** Does what a click on the row does in the grid. */
  open: () => void;
  /** Kanban only: the value of the column the card sits in. */
  groupValue?: string;
  /**
   * `cards` only, on a hand-ordered table (backend `reorder`) and for a
   * caller who may edit: the card's move handle, to draw somewhere on it.
   */
  reorder?: TableViewCardReorder;
  /**
   * `cards` only: the row's actions as the grid row offers them (its inline
   * buttons and its … menu, with their rules and confirmations), to draw
   * with `<component :is="rowActions" />`. It draws nothing for a table with
   * no row action, and stops its clicks from reaching the card.
   */
  rowActions?: Component;
}

/**
 * The props a custom detail band receives (backend `expandable.component`):
 * a card's, without the selection the grid row above it already shows.
 */
export interface TableViewExpandedRowProps<T = Data> {
  /** The row the band details: the listed one, or the one `lazyLoad` read. */
  row: T;
  /** Its id (its `rowIdKey` value). */
  rowId: string;
  /** Column metadata of the table view (types, labels). */
  columns: TableViewColumn[];
  /** Field naming the row, if configured. */
  labelKey?: string;
  /** The table's row actions and their per-row predicates. */
  actions: TableViewDisplayActions<T>;
  /** Does what a click on the row does in the grid. */
  open: () => void;
  /** Reloads the table, and with it the open bands. */
  refresh: () => Promise<void> | void;
}

/**
 * The single, normalized prop every display component receives. A display reads
 * what it needs and ignores the rest; everything is sourced from the table
 * view's existing state/handlers so a display inherits search/filters/sorting/
 * pagination for free (when it consumes the shared list query).
 */
export interface TableViewDisplayContext<T = Data> {
  /** Current page rows from the shared list query. Empty for self-managed displays. */
  items: T[];
  /** Full column metadata (types, labels, accessor keys) — for field rendering. */
  columns: TableViewColumn[];
  /** The shared query is in flight: a first read or any re-read. */
  loading: boolean;
  /**
   * No answer has arrived yet: draw a skeleton. A re-read keeps the rows,
   * or the empty state, on screen; swapping either for a skeleton flashes.
   */
  firstPageLoading: boolean;

  selection: TableViewDisplaySelection;
  pagination: TableViewDisplayPagination;
  actions: TableViewDisplayActions<T>;

  presenceByRow: TableViewPresenceMap;
  rowIdKey: string;
  /** Field used as the human label/title of an item, if configured. */
  labelKey?: string;
  /** Data API location (`{location}/list`, `/get`, ...). Needed by self-managed displays. */
  location: string;
  /** Active filters/search/sort query (no limit/offset) — for self-managed fetching. */
  query: Record<string, unknown>;
  /** Stable component/page identifiers, e.g. for per-instance fetch keys. */
  componentId?: string;
  pageId?: string;
  /** Per-instance options declared for this display in the backend config. */
  options?: Record<string, unknown>;
  /**
   * A self-managed display hands the rows it shows, in the order the user
   * reads them (a board: column by column), each time they change: a row
   * opened from it steps through them in its drawer or side panel ("3 of
   * 12", previous / next, J and K). Without it, a self-managed display's row
   * opens without steps. The shared list's displays need not call it.
   */
  setShownRows?: (rows: T[]) => void;
  /** Re-fetch the table view (shared list + tab counts + active display). */
  refresh: () => Promise<void> | void;
  /**
   * Rows ordered by hand (backend `reorder`): set on the grid and the
   * `cards` display, for a caller who may edit the rows.
   */
  reorder?: TableViewDisplayReorder;

  /**
   * Escape hatch: the TanStack table instance, present when the display is
   * rendered inside the table body slot. Advanced displays only.
   */
  table?: Table<T>;
}

/**
 * What chrome the table view shows while a display is active. Column-centric
 * controls (visibility/pin/size/order) are grid-only; transverse controls
 * (filters/search/sorting/tabs) default on. Resolved by
 * `resolveDisplayCapabilities`.
 */
export interface TableViewDisplayCapabilities {
  /** Column visibility/pin/size/order controls. Default false (grid sets true). */
  columnManagement?: boolean;
  /** Filters row + filter trigger. Default true. */
  filters?: boolean;
  /** Global search box. Default true. */
  search?: boolean;
  /** Sort-by-field menu. Default true. */
  sorting?: boolean;
  /** Filter tabs. Default true (kanban: false). */
  tabs?: boolean;
  /**
   * The table's own chrome above the body: caption, actions toolbar, tabs,
   * filters row and bulk-selection bar. Default true; a display that draws a
   * complete interface of its own sets it to false.
   */
  header?: boolean;
}

/** Lightweight context passed to {@link TableViewDisplay.isAvailable}. */
export interface TableViewDisplayAvailabilityContext {
  columns: TableViewColumn[];
  options?: TableViewDisplayContext["options"];
}

/**
 * A registered display: a built-in one ("table", "kanban", "cards") or one a
 * module contributes under `<module>:<id>`, registered from a universal plugin
 * via `registerTableViewDisplay`. Holds
 * presentation only; data behaviour (selfManagedData) and chrome (capabilities)
 * live on the backend config (SSR source of truth) — see TableViewDisplayConfig.
 */
export interface TableViewDisplay {
  /**
   * Stable id; matches `displays[].id` / `defaultDisplay` and the persisted
   * preference. A module's display is `<module>:<id>`.
   */
  id: string;
  /** i18n key or literal label shown in the view switcher. */
  label: string;
  /** Icon shown in the view switcher (e.g. "i-ph-cards"). */
  icon: string;
  /**
   * Body renderer. A `ComponentInfo` (name) is resolved via `resolveDmsComponent`;
   * a raw `Component` is used as-is. `undefined` means "render the built-in grid"
   * (used by the `table` display).
   */
  component?: Component | ComponentInfo;
  /** Switcher ordering; lower comes first. Defaults to 100. */
  order?: number;
  /** Hide the display for a given table instance (e.g. kanban needs an eligible column). */
  isAvailable?: (ctx: TableViewDisplayAvailabilityContext) => boolean;
}

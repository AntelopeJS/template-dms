/**
 * Stand-in for the host runtime the DMS frontend loader materializes as
 * `#dms/frontend-module`. Only what this package imports from the host is
 * declared.
 */
import englishMessages from '../../../i18n/locales/builder-en-GB.json'
import frenchMessages from '../../../i18n/locales/builder-fr-FR.json'

type Messages = { [key: string]: string | Messages }

function lookup(messages: Messages, path: string): string | undefined {
  let node: string | Messages | undefined = messages
  for (const part of path.split('.')) {
    node = typeof node === 'object' ? node[part] : undefined
  }
  return typeof node === 'string' ? node : undefined
}

/** vue-i18n's default choice: `zero | one | many`, or `one | many`. */
function pluralForm(message: string, count: number | undefined): string {
  const forms = message.split(' | ')
  if (count === undefined || forms.length === 1) {
    return message
  }
  const index =
    forms.length === 2 ? (count === 1 ? 0 : 1) : Math.min(Math.abs(count), 2)
  return forms[index] ?? message
}

export type TestLocale = 'en-GB' | 'fr-FR'

let locale: TestLocale = 'en-GB'

/** Switches the locale `translate` reads; a test restores `en-GB` when it is done. */
export function setTestLocale(next: TestLocale): void {
  locale = next
}

/**
 * The application composer, reading the module's catalog in the test locale,
 * English unless a test switches it: a test asserts the texts an
 * English-speaking author sees, and a key the catalog lacks comes back as
 * itself, as vue-i18n returns it.
 */
function translate(
  key: string,
  params: Record<string, unknown> = {},
  count?: number,
): string {
  const message =
    lookup((locale === 'fr-FR' ? frenchMessages : englishMessages) as Messages, key) ??
    lookup(englishMessages as Messages, key)
  if (message === undefined) {
    return key
  }
  return pluralForm(message, count).replace(/\{(\w+)\}/g, (match, name: string) =>
    name in params ? String(params[name]) : match,
  )
}

export function useDmsApp(): { $i18n: { t: typeof translate } } {
  return { $i18n: { t: translate } }
}
